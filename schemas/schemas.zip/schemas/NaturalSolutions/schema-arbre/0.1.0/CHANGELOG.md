---
permalink: /NaturalSolutions/schema-arbre/latest/changelog.html
redirect_from: /NaturalSolutions/schema-arbre/0.1.0/changelog.html
title: CHANGELOG de Schéma des attributs des arbres urbains
version: 0.1.0
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1.0 - 2020-10-16

Publication initiale.