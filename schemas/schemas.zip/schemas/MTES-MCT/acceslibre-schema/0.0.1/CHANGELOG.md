---
permalink: /MTES-MCT/acceslibre-schema/latest/changelog.html
redirect_from: /MTES-MCT/acceslibre-schema/0.0.1/changelog.html
title: CHANGELOG de Schéma des données d'accessibilité des ERPs
version: 0.0.1
---

## Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

### Version 0.0.1 - 11-05-2021

Publication initiale.