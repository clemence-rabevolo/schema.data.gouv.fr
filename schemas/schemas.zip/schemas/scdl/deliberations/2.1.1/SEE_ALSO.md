---
permalink: /scdl/deliberations/2.1.1/SEE_ALSO.html
redirect_from: null
title: 'Documentation de Délibérations : propriété SEE_ALSO'
version: 2.1.1
---

La spécification du modèle de données peut être utilement complétée par les documents suivants :

* Fichier gabarit à exporter
* [Schéma de validation](https://git.opendatafrance.net/scdl/deliberations/blob/master/schema.json)

Pour poser une question, commenter, faire un retour d’usage ou contribuer à l’amélioration du modèle de données, vous pouvez :

* adresser un message à [scdl@opendatafrance.email](mailto:scdl@opendatafrance.email?subject=Délibérations)
* ouvrir un ticket sur le [dépôt GitLab d’OpenDataFrance](https://git.opendatafrance.net/scdl/deliberations/issues/new)