---
permalink: /etalab/schema-amenagements-cyclables/latest/changelog.html
redirect_from: /etalab/schema-amenagements-cyclables/0.2.3/changelog.html
title: CHANGELOG de Schéma d'aménagements cyclables
version: 0.2.3
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma

## Version 0.1.0 - 2020-09-18

Publication initiale.