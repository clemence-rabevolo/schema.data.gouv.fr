---
permalink: /etalab/schema-hautes-remunerations/latest/changelog.html
redirect_from: /etalab/schema-hautes-remunerations/0.1.0/changelog.html
title: CHANGELOG de Hautes rémunérations dans la fonction publique
version: 0.1.0
---

# Changelog

## Version 0.1.0 - 2020-09-23

Publication initiale.