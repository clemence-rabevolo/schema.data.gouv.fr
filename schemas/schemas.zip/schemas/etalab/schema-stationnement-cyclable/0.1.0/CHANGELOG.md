---
permalink: /etalab/schema-stationnement-cyclable/latest/changelog.html
redirect_from: /etalab/schema-stationnement-cyclable/0.1.0/changelog.html
title: CHANGELOG de Stationnement cyclable
version: 0.1.0
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1 2021-04-15

- Première version publiée du schéma du stationnement cyclable