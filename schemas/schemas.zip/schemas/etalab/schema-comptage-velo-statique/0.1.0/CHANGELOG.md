---
permalink: /etalab/schema-comptage-velo-statique/latest/changelog.html
redirect_from: /etalab/schema-comptage-velo-statique/0.1.0/changelog.html
title: CHANGELOG de Schéma du comptage vélo (partie statique)
version: 0.1.0
---

# Changelog

Ce fichier répertorie les changements entre différentes versions d'un schéma.

## Version 0.1

- Première version publiée du schéma